package com.example.lifelike;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class ProfileActivity extends AppCompatActivity {

    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private TextView emailTextView;
    private EditText nameEditText, ageEditText;
    private Button saveButton;
    private ImageView saludImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        emailTextView = findViewById(R.id.emailTextView);
        nameEditText = findViewById(R.id.nameEditText);
        ageEditText = findViewById(R.id.ageEditText);
        saveButton = findViewById(R.id.saveButton);
        saludImageView = findViewById(R.id.imageView4);

        // Obtener el usuario actual
        FirebaseUser user = auth.getCurrentUser();
        if (user != null) {
            // Mostrar la dirección de correo electrónico del usuario
            emailTextView.setText(user.getEmail());

            // Cargar datos existentes del usuario
            loadUserData(user.getUid());
        } else {
            // Redirigir a la pantalla de autenticación si no hay usuario autenticado
            startActivity(new Intent(this, AuthActivity.class));
            finish();
        }

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUserData();
            }
        });

        // Añadir el listener para la imagen de salud
        saludImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirigir a MainActivity2
                Intent intent = new Intent(ProfileActivity.this, MainActivity2.class);
                startActivity(intent);
            }
        });
    }

    private void loadUserData(String userId) {
        db.collection("users").document(userId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String name = documentSnapshot.getString("name");
                        String age = documentSnapshot.getString("age");
                        nameEditText.setText(name);
                        ageEditText.setText(age);
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(ProfileActivity.this, "Error al cargar datos: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void saveUserData() {
        FirebaseUser user = auth.getCurrentUser();
        if (user != null) {
            String name = nameEditText.getText().toString().trim();
            String age = ageEditText.getText().toString().trim();

            Map<String, Object> userData = new HashMap<>();
            userData.put("name", name);
            userData.put("age", age);

            db.collection("users").document(user.getUid()).set(userData)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(ProfileActivity.this, "Datos guardados exitosamente", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(ProfileActivity.this, "Error al guardar datos: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        }
    }
}