package com.example.lifelike

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

enum class ProviderType {
    BASIC
}

class HomeActivity : AppCompatActivity() {

    private lateinit var emailTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Obtener datos del Intent
        val email = intent.getStringExtra("EMAIL")
        val provider = intent.getStringExtra("PROVIDER")

        // Setup con los datos proporcionados
        setup(email, provider)
    }

    private fun setup(email: String?, provider: String?) {
        title = "Inicio"

        // Referencia al elemento del diseño
        emailTextView = findViewById(R.id.emailTextView)

        // Puedes manejar el caso cuando el email o el provider son nulos
        if (email != null && provider != null) {
            // Actualizar el TextView con el email y el provider
            emailTextView.text = "Email: $email - Provider: $provider"
        } else {
            // Manejar el caso cuando los datos son nulos
            emailTextView.text = "Error: Datos de usuario no disponibles"
        }
    }
}

